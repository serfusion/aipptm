<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function aipptm_setup() {
	add_editor_style( 'style.css' );
}
add_action( 'after_setup_theme', 'aipptm_setup' );

function aipptm_enqueue_styles() {
	wp_enqueue_style( 'aipptm', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );
	wp_enqueue_script( 'aipptm-terjemah', get_theme_file_uri( 'assets/js/terjemah.js' ), array(), wp_get_theme()->get( 'Version' ), array( 'strategy' => 'defer', 'in_footer' => true ) );
	wp_enqueue_script( 'aipptm-gerak', get_theme_file_uri( 'assets/js/gerak.js' ), array(), wp_get_theme()->get( 'Version' ), array( 'strategy' => 'defer', 'in_footer' => false ) );
}
add_action( 'wp_enqueue_scripts', 'aipptm_enqueue_styles' );

function aipptm_register_pattern_category() {
	register_block_pattern_category( 'aipptm', array( 'label' => __( 'AIPPTM', 'aipptm' ) ) );
}
add_action( 'init', 'aipptm_register_pattern_category' );

function aipptm_kepala( $judul, $pengantar ) {
	printf(
		'<!-- wp:group {"align":"wide","className":"aipptm-kepala","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group alignwide aipptm-kepala"><!-- wp:heading {"className":"aipptm-kepala__judul"} -->
<h2 class="wp-block-heading aipptm-kepala__judul">%1$s<mark style="background-color:rgba(0, 0, 0, 0)" class="has-inline-color has-merah-color">.</mark></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"aipptm-kepala__pengantar"} -->
<p class="aipptm-kepala__pengantar">%2$s</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

',
		esc_html( $judul ),
		wp_kses( $pengantar, array( 'strong' => array() ) )
	);
}

function aipptm_tahun_berjalan( $content, $block ) {
	$kelas = isset( $block['attrs']['className'] ) ? $block['attrs']['className'] : '';
	if ( false === strpos( $kelas, 'aipptm-hak-cipta' ) ) {
		return $content;
	}
	return preg_replace( '/\b(19|20)\d{2}\b/', wp_date( 'Y' ), $content, 1 );
}
add_filter( 'render_block_core/paragraph', 'aipptm_tahun_berjalan', 10, 2 );

function aipptm_pilihan_bahasa( $content, $block ) {
	$kelas = isset( $block['attrs']['className'] ) ? $block['attrs']['className'] : '';
	if ( false === strpos( $kelas, 'aipptm-bahasa' ) ) {
		return $content;
	}
	$daftar = function_exists( 'pll_the_languages' ) ? pll_the_languages(
		array(
			'raw'           => 1,
			'hide_if_empty' => 0,
		)
	) : array();
	if ( empty( $daftar ) || ! is_array( $daftar ) ) {
		$item = '';
		foreach ( array( 'id' => 'Indonesia', 'en' => 'English', 'ar' => 'العربية', 'zh-CN' => '中文' ) as $kode => $nama ) {
			$item .= sprintf(
				'<li><a href="#" data-terjemah="%1$s" hreflang="%1$s" title="%2$s"%3$s>%4$s</a></li>',
				esc_attr( $kode ),
				esc_attr( $nama ),
				'id' === $kode ? ' class="is-aktif"' : '',
				esc_html( strtoupper( substr( $kode, 0, 2 ) ) )
			);
		}
		return '<nav class="aipptm-bahasa aipptm-bahasa--otomatis notranslate" translate="no" aria-label="' . esc_attr__( 'Pilihan bahasa', 'aipptm' ) . '"><ul>' . $item . '</ul></nav><div id="aipptm-gt" hidden></div>';
	}
	$item = '';
	foreach ( $daftar as $bahasa ) {
		$item .= sprintf(
			'<li><a href="%1$s" hreflang="%2$s" lang="%2$s" title="%3$s"%4$s>%5$s</a></li>',
			esc_url( $bahasa['url'] ),
			esc_attr( ! empty( $bahasa['locale'] ) ? str_replace( '_', '-', $bahasa['locale'] ) : $bahasa['slug'] ),
			esc_attr( $bahasa['name'] ),
			! empty( $bahasa['current_lang'] ) ? ' aria-current="true" class="is-aktif"' : '',
			esc_html( strtoupper( $bahasa['slug'] ) )
		);
	}
	return '<nav class="aipptm-bahasa notranslate" translate="no" aria-label="' . esc_attr__( 'Pilihan bahasa', 'aipptm' ) . '"><ul>' . $item . '</ul></nav>';
}
add_filter( 'render_block_core/paragraph', 'aipptm_pilihan_bahasa', 10, 2 );

require get_template_directory() . '/inc/starter-content.php';
