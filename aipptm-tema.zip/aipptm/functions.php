<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function aipptm_setup() {
	add_editor_style( 'style.css' );
}
add_action( 'after_setup_theme', 'aipptm_setup' );

function aipptm_enqueue_styles() {
	wp_enqueue_style( 'aipptm', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );
	wp_enqueue_script( 'aipptm-terjemah', get_theme_file_uri( 'assets/js/terjemah.js' ), array(), wp_get_theme()->get( 'Version' ), array( 'strategy' => 'defer', 'in_footer' => true ) );
	wp_enqueue_script( 'aipptm-gerak', get_theme_file_uri( 'assets/js/gerak.js' ), array(), wp_get_theme()->get( 'Version' ), array( 'strategy' => 'defer', 'in_footer' => false ) );
	wp_enqueue_script( 'aipptm-saring', get_theme_file_uri( 'assets/js/saring.js' ), array(), wp_get_theme()->get( 'Version' ), array( 'strategy' => 'defer', 'in_footer' => true ) );
}
add_action( 'wp_enqueue_scripts', 'aipptm_enqueue_styles' );

function aipptm_register_pattern_category() {
	register_block_pattern_category( 'aipptm', array( 'label' => __( 'AIPPTM', 'aipptm' ) ) );
}
add_action( 'init', 'aipptm_register_pattern_category' );

function aipptm_kepala( $judul, $pengantar ) {
	printf(
		'<!-- wp:group {"align":"wide","className":"aipptm-kepala","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group alignwide aipptm-kepala"><!-- wp:heading {"className":"aipptm-kepala__judul"} -->
<h2 class="wp-block-heading aipptm-kepala__judul">%1$s<mark style="background-color:rgba(0, 0, 0, 0)" class="has-inline-color has-merah-color">.</mark></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"aipptm-kepala__pengantar"} -->
<p class="aipptm-kepala__pengantar">%2$s</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

',
		esc_html( $judul ),
		wp_kses( $pengantar, array( 'strong' => array() ) )
	);
}

function aipptm_pemisah() {
	echo '<!-- wp:separator {"align":"wide","backgroundColor":"merah-tua","style":{"spacing":{"margin":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<hr class="wp-block-separator alignwide has-text-color has-merah-tua-color has-alpha-channel-opacity has-merah-tua-background-color has-background" style="margin-top:var(--wp--preset--spacing--60);margin-bottom:var(--wp--preset--spacing--60)"/>
<!-- /wp:separator -->

';
}

function aipptm_tahun_berjalan( $content, $block ) {
	$kelas = isset( $block['attrs']['className'] ) ? $block['attrs']['className'] : '';
	if ( false === strpos( $kelas, 'aipptm-hak-cipta' ) ) {
		return $content;
	}
	return preg_replace( '/\b(19|20)\d{2}\b/', wp_date( 'Y' ), $content, 1 );
}
add_filter( 'render_block_core/paragraph', 'aipptm_tahun_berjalan', 10, 2 );

function aipptm_bendera( $kode, $nama ) {
	$peta = array( 'id' => 'id', 'en' => 'gb', 'ar' => 'sa', 'zh' => 'cn' );
	$kode = strtolower( substr( $kode, 0, 2 ) );
	$file = isset( $peta[ $kode ] ) ? $peta[ $kode ] : '';
	if ( '' === $file ) {
		return esc_html( strtoupper( $kode ) );
	}
	return sprintf(
		'<img src="%1$s" alt="%2$s" width="22" height="22" class="aipptm-bendera">',
		esc_url( get_theme_file_uri( 'assets/flags/' . $file . '.svg' ) ),
		esc_attr( $nama )
	);
}

function aipptm_kelas_peringkat( $content, $block ) {
	$kelas = isset( $block['attrs']['className'] ) ? $block['attrs']['className'] : '';
	if ( ! preg_match( '/(?:^|\s)aipptm-(sinta|akreditasi)(?:\s|$)/', $kelas, $jenis ) || ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
		return $content;
	}
	$teks = strtolower( trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $content ) ) ) );
	if ( 'sinta' === $jenis[1] ) {
		if ( ! preg_match( '/([1-6])/', $teks, $angka ) ) {
			return $content;
		}
		$varian = 'aipptm-sinta--' . $angka[1];
	} else {
		$peta   = array(
			'unggul'        => 'unggul',
			'baik sekali'   => 'baik-sekali',
			'baik'          => 'baik',
			'a'             => 'a',
			'b'             => 'b',
			'c'             => 'c',
			'terakreditasi' => 'terakreditasi',
		);
		$varian = 'aipptm-akreditasi--' . ( isset( $peta[ $teks ] ) ? $peta[ $teks ] : 'proses' );
	}
	$tag = new WP_HTML_Tag_Processor( $content );
	if ( ! $tag->next_tag() ) {
		return $content;
	}
	$tag->add_class( $varian );
	return $tag->get_updated_html();
}
add_filter( 'render_block_core/paragraph', 'aipptm_kelas_peringkat', 10, 2 );

function aipptm_pilihan_bahasa( $content, $block ) {
	$kelas = isset( $block['attrs']['className'] ) ? $block['attrs']['className'] : '';
	if ( false === strpos( $kelas, 'aipptm-bahasa' ) ) {
		return $content;
	}
	$daftar = function_exists( 'pll_the_languages' ) ? pll_the_languages(
		array(
			'raw'           => 1,
			'hide_if_empty' => 0,
		)
	) : array();
	if ( empty( $daftar ) || ! is_array( $daftar ) ) {
		$item = '';
		foreach ( array( 'id' => 'Indonesia', 'en' => 'English', 'ar' => 'العربية', 'zh-CN' => '中文' ) as $kode => $nama ) {
			$item .= sprintf(
				'<li><a href="#" data-terjemah="%1$s" hreflang="%1$s" title="%2$s"%3$s>%4$s</a></li>',
				esc_attr( $kode ),
				esc_attr( $nama ),
				'id' === $kode ? ' class="is-aktif"' : '',
				aipptm_bendera( $kode, $nama )
			);
		}
		return '<nav class="aipptm-bahasa aipptm-bahasa--otomatis notranslate" translate="no" aria-label="' . esc_attr__( 'Pilihan bahasa', 'aipptm' ) . '"><ul>' . $item . '</ul></nav><div id="aipptm-gt" hidden></div>';
	}
	$item = '';
	foreach ( $daftar as $bahasa ) {
		$item .= sprintf(
			'<li><a href="%1$s" hreflang="%2$s" lang="%2$s" title="%3$s"%4$s>%5$s</a></li>',
			esc_url( $bahasa['url'] ),
			esc_attr( ! empty( $bahasa['locale'] ) ? str_replace( '_', '-', $bahasa['locale'] ) : $bahasa['slug'] ),
			esc_attr( $bahasa['name'] ),
			! empty( $bahasa['current_lang'] ) ? ' aria-current="true" class="is-aktif"' : '',
			aipptm_bendera( $bahasa['slug'], $bahasa['name'] )
		);
	}
	return '<nav class="aipptm-bahasa notranslate" translate="no" aria-label="' . esc_attr__( 'Pilihan bahasa', 'aipptm' ) . '"><ul>' . $item . '</ul></nav>';
}
add_filter( 'render_block_core/paragraph', 'aipptm_pilihan_bahasa', 10, 2 );

require get_template_directory() . '/inc/starter-content.php';
